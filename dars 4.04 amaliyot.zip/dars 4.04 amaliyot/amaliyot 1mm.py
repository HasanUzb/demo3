def list_funksiya(list1):
    if not list1:
        raise ValueError("Listni ichi bosh")

    max_value = list1[0]
    for numbers in list1:
        if numbers > max_value:
            max_value = numbers
    return max_value

list2 = (3, 6, 8, 1, 0)
natija = list_funksiya(list2)
print(f"Listdagi eng kotta qiymat: {natija}")
