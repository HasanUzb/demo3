def funksiya(a: int) -> int:
    return a ** 2

a_list = [1, 4, 2, 3, 5]
b_list = list(map(funksiya, a_list))

print(b_list)
