def tub_sonlar(son):
    if son <= 1:
        return False
    for i in range(2, int(son**0.5) + 1):
        if son % i == 0:
            return False
    return True

list1 = [5, 12, 17, 18, 24, 32, 19, 0, 21]

list2 = list(filter(tub_sonlar, list1))

print(list2)
