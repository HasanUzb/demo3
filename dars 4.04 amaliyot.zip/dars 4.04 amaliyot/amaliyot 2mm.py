def peremetr_yuza(a: int , b: int) -> int:
    return ( 2 * (a + b) , a * b )

print(peremetr_yuza(int(input("a: ")), int(input("b: "))))


