def funksiya1(set1, set2):

    return set1.intersection(set2)

set_a = {1, 2, 3, 4, 5}
set_b = {4, 5, 6, 7, 8}
result = funksiya1(set_a, set_b)
print(result)  
